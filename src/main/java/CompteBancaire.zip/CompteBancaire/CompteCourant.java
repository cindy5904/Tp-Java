package CompteBancaire;

public class CompteCourant extends CompteBancaire{
    public CompteCourant(double solde, Client client) {
        super(solde, client);
    }
}
