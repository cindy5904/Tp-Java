package CompteBancaire;

public class CompteEpargne extends CompteBancaire{
    public CompteEpargne(double solde, Client client) {
        super(solde, client);
    }

}
