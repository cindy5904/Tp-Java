package CompteBancaire;

public class ComptePayant extends CompteBancaire{
    public ComptePayant(double solde, Client client) {
        super(solde, client);
    }
}
