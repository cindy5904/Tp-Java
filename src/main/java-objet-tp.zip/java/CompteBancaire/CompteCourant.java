package CompteBancaire;

public class CompteCourant extends CompteBancaire{
}
