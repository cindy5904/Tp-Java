package CompteBancaire;

public class CompteEpargne extends CompteBancaire{
}
