package CompteBancaire;

public class ComptePayant extends CompteBancaire{
}
