package CompteBancaire;

public class CompteBancaire {
    protected int solde;

    public CompteBancaire() {
        this.solde = 0;
    }

    public int getSolde() {
        return solde;
    }

    public void setSolde(int solde) {
        this.solde = solde;
    }
}
