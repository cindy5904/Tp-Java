package Pendu;

public class IHM {

}
