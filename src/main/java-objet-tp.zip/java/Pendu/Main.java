package Pendu;

public class Main {
    public static void main(String[] args) {

    }
}
