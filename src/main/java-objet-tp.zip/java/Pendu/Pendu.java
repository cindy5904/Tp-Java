package Pendu;

public class Pendu {
}
