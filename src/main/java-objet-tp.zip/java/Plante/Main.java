package Plante;

public class Main {
    public static void main(String[] args) {
        Plante plante1 = new Plante("Tulipe", 20, "Jaune");
        System.out.println(plante1);
        System.out.println();

        Arbre arbre1 = new Arbre("Palmier", 300, "Vert", 5);
        System.out.println(arbre1);
    }
}
